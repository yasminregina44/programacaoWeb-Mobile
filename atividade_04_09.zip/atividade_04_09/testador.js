const questao1 = require('./questao1');

const resultado = questao1.numerosPrimos(5);

console.log(resultado);



const questao2 = require('./questao2');

const resultado2 = questao2.media([0,12]);

console.log(resultado2);



const questao3 =require('./questao3');

const resultado3= questao3.celsiusFahrenheit(13);

const resultado4=questao3.fahrenheitKelvin(21);

const resultado5=questao3.kelvinCelsius(34);

console.log(resultado3);
console.log(resultado4);
console.log(resultado5);



const questao4 = require('./questao4');

const resultado6=questao4.quadrado(3);

const resultado7=questao4.circulo(4);

const resultado8=questao4.triangulo(7);

console.log(resultado6);
console.log(resultado7);
console.log(resultado8);



const questao5=require('./questao5');

const resultado9=questao5.adicao(2,6);

const resultado10=questao5.subtracao(4,8);

const resultado11=questao5.multiplicação(5,8);

const resultado12=questao5.divisao(20,5);

const resultado13=questao5.calcularString('1+2');

console.log(resultado9);
console.log(resultado10);
console.log(resultado11);
console.log(resultado12);
console.log(resultado13);